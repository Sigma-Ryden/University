﻿var phoneBook = []; // Тут ви зберігаєте записи як хочете

/*
   Функція додавання запису в телефонну книгу.
*/
phoneBook.add = function (name, phone, email) {
  phoneBook.push({ name: name, phone: phone, email: email });
};

/*
   Функція пошуку записів в телефонній книзі.
   Пошук ведеться по всім полям.
*/
phoneBook.find = function (query) {
  for (let obj of phoneBook) {
    for(let key in obj) {
      if(obj[key].indexOf(query) !== -1) {
        document.write(obj.name + ", " +
          obj.phone + ", " +
          obj.email + "<br>");
      }
    }
  }
};

/*
   Функція видалення запису в телефонній книзі.
*/
phoneBook.remove = function (query) {
  let count = 0;
  for (let obj of phoneBook) {
    for(let key in obj) {
      if(obj[key].indexOf(query) !== -1) {
        phoneBook.pop();
        ++count;
      }
    }
  }
  document.write("Вилучено " + count + " контакт<br>");
};

/*
   Функція виведення всіх телефонів.
*/
phoneBook.showTable = function (){
  document.write("<table><tr><td>Ім'я</td><td>Телефон</td><td>email</td></tr>");
  for (let obj of phoneBook) {
    document.write("<tr><td>" + obj.name + "</td><td>" +
      obj.phone + "</td><td>" + obj.email + "</td></tr>");
  }
  document.write("</table><br>");
}