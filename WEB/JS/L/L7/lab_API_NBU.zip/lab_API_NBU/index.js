const currentDateView = document.getElementById('currentdate');
const ratesView = document.getElementById('rates');
const rateHistoryView = document.getElementById('ratehistory');

let within = 7;

currentDateView.textContent = new Date().toLocaleDateString();
setAPI();
document.addEventListener('DOMContentLoaded', start);

function setAPI() {
	currentDateView.innerHTML +=
	`<form>
		<select>
	        <option value="7">По умолчанию</option>
	        <option value="1">1 День</option>
	        <option value="2">2 Дня</option>
	        <option value="7">1 Неделя</option>
	        <option value="14">2 Недели</option>
	        <option value="30">1 Месяц</option>
	        <option value="60">2 Месяца</option>
	        <option value="users">Вручную</option>
	   	</select>
   		<input type="button" value="Set" onclick="getRateWithin()">
	</form>`;
}

function isNumber(str) {
	return str.toLowerCase() === str.toUpperCase();
}

function getRateWithin() {
	let option = document.querySelector('select');
	if (option.value === 'users') {
		let tempStr = prompt("Количество дней (диапазон): ", 15);
		if (!isNumber(tempStr)) {
			alert("Введите целое число!");
			within = 7;
		} else {
			if (tempStr === '0') tempStr = '1';
			within = Math.abs(parseInt(tempStr)) % 365;
		}
	} else {
		within = option.value;
	}
}

function start() {
	fetch('https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json')
    .then(result => result.json())
    .then(json => renderRates(json))
    .catch(e => console.error(e));
}

function renderRates(rates) {
	rates
		.map(rate => renderRate(rate))
		.forEach(rate => ratesView.appendChild(rate));
}
function renderRate(rate) {
	const li = document.createElement('li');
	li.innerHTML = `<span class="" onclick="getRateHistory('${rate.cc}')">${rate.txt} - ${rate.rate}</span>`;
	return li;
}

function getRateHistory(cc) {
	rateHistoryView.innerHTML = "";
	const dates = getDateList();
	Promise.all(
		dates.map(date => getRate(`https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?valcode=${cc}&date=${date}&json`))
	)
	.then(
		date => date.map( day => renderRateHistory(day[0]) ) 
	);
}

function renderRateHistory(rate) {
	rateHistoryView.innerHTML += `<li>${rate.exchangedate} - ${rate.txt} - ${rate.cc} - ${rate.rate}</li>`;
}

async function getRate(url) {
	const res = await fetch(url);
	const json = await res.json();
	return json;
}
function getDateList() {
	const dayMilliseconds = 24 * 60 * 60 * 1000;
	let currentDate = new Date();

	let dateList = [];

	for (let i = 0; i < within; ++i) {
		dateList.push(currentDate.toLocaleDateString().split('.').reverse().join(''));
		currentDate.setTime(currentDate.getTime() - dayMilliseconds);
	}

	return dateList;
}