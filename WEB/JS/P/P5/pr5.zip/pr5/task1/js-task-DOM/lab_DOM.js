﻿//task 1 Використовуйте метод getElementById для пошуку <h2> елемента та змініть його текст на "Привіт".
let task1 = document.getElementById('banner').innerText = "Привіт";
//task 2 Використовуйте метод getElementsByTagName, щоб знайти третій <li> елемент, і змініть його текст на "Світ".
let task2 = document.getElementsByTagName('li')[2].innerText = "Світ";
//task 3 Змініть текст другого елемента, з класом "tests" на "Ще трошки попрацюйте".
let task3 = document.getElementsByClassName('tests')[1].innerText = "Ще трошки попрацюйте"
//task 4 За допомогою властивостей, встновить калас "selected" у третього <li> елементу
let task4 = document.getElementsByTagName('li')[2].setAttribute('class', 'selected');
//task 5 Встановіть атрибут title із значенням 'Вже половина завдань' для елемента <p class="tests">
let task5 = document.getElementsByClassName('tests')[1].setAttribute('title', 'Вже половина завдань');
//task 6 Змініть колір другого абзацу на червоний
let task6 = document.getElementsByClassName('tests')[1].style.color = 'rgb(255, 0, 0)';
//task 7 Задайте розмір шрифту для другого абзацу 40px
let task7 = document.getElementsByClassName('tests')[1].style.fontSize = '40px';
//task 8 Задайте властивість float: left для елементів списку
let task8 = document.getElementsByTagName('li');
for(i of task8) {
    i.style.cssFloat = 'left';
}
//task 9  Видаліть заголовок h1 з текстом "My Foo Tests"
let task9 = document.querySelector('h1').remove();
//let task9 = document.getElementsByTagName('h1')[0].remove();