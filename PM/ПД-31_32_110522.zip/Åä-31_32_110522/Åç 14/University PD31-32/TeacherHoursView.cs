﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    // Collaboration: TeacherHours
    class TeacherHoursView : IId
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Hours { get; set; }
        public TeacherHoursView(string Name, string Surname, int Hours)
        {
            this.Name = Name;
            this.Surname = Surname;
            this.Hours = Hours;
        }
        public override string ToString()
        {
            return String.Format(Id + " " + Name + " " + Surname + " " + Hours);
        }
    }
}
