﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    // Collaboration: TeacherHours
    class DepartmentService
    {
        private DBItem<Teacher> dbTeacher;
        private DBItem<Subject> dbSubject;
        private DBItem<SubjectTeacher> dbSubjectTeacher;
        private DBItem<TeacherHoursView> dbTeacherHoursView;
        public DepartmentService(DBItem<Teacher> dbTeacher, DBItem<Subject> dbSubject, DBItem<SubjectTeacher> dbSubjectTeacher, DBItem<TeacherHoursView> dbTeacherHoursView)
        {
            this.dbTeacher = DBItem<Teacher>.Instance();
            //this.dbTeacher = dbTeacher;
            this.dbSubject = dbSubject;
            this.dbSubjectTeacher = dbSubjectTeacher;
            this.dbTeacherHoursView = dbTeacherHoursView;
        }
        public DBItem<TeacherHoursView> ShowTeacherHours()
        {
            int sumHours = 0;
            foreach(Teacher t in dbTeacher.Items)
            {
                sumHours = 0;
                foreach(SubjectTeacher st in dbSubjectTeacher.Items)
                {
                    if(t.Id == st.TeacherId)
                    {
                        foreach(Subject s in dbSubject.Items)
                        {
                            if(s.Id == st.SubjectId)
                            {
                                sumHours = sumHours + s.Hours;
                            }
                        }
                    }
                }
                dbTeacherHoursView.AddItem(new TeacherHoursView(t.Name, t.Surname, sumHours));
            }
            return dbTeacherHoursView;
        }
    }
}
