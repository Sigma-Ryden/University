﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    // Collaboration: TeacherHours
    class DepartmentMenu
    {
        DepartmentUI departmentUI;
        public DepartmentMenu(DepartmentUI departmentUI)
        {
            this.departmentUI = departmentUI;
        }
        public void Run()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Department_Menu:");
                Console.WriteLine("1 - ShowTeacherHours");
                Console.WriteLine("2 - Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        departmentUI.ShowTeacherHours();
                        break;
                    case 2:
                        Console.WriteLine("Exit");
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("Wrong choice!");
                        break;
                }
            }
        }

    }
}
