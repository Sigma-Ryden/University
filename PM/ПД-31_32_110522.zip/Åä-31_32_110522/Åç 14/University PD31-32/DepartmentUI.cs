﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    // Collaboration: TeacherHours
    class DepartmentUI
    {
        DepartmentService departmentService;
        public DepartmentUI(DepartmentService departmentService)
        {
            this.departmentService = departmentService;
        }
        public void ShowTeacherHours()
        {
            DBItem<TeacherHoursView> dbTeacherHoursView = departmentService.ShowTeacherHours();
            foreach(TeacherHoursView thv in dbTeacherHoursView.Items)
            {
                Console.WriteLine(thv);
            }
        }
    }
}
