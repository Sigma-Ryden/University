﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    interface IId
    {
        int Id { get; set; }
    }
}
