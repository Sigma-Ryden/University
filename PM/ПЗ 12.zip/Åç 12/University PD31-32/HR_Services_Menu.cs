﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    class HR_Services_Menu
    {
        HR_UI hr_UI;
        public HR_Services_Menu(HR_UI hr_UI)
        {
            this.hr_UI = hr_UI;
        }
        public void Run()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("HR_Services_Menu:");
                Console.WriteLine("1 - ShowStudentAddress");
                Console.WriteLine("2 - Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        //Console.WriteLine("ShowStudentAddress");
                        hr_UI.ShowStudentAddress();
                        break;
                    case 2:
                        Console.WriteLine("Exit");
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("Wrong choice!");
                        break;
                }
            }
        }
    }
}
