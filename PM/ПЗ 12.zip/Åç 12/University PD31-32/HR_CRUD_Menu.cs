﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    class HR_CRUD_Menu
    {
        HR_UI hr_UI;
        public HR_CRUD_Menu(HR_UI hr_UI)
        {
            this.hr_UI = hr_UI;
        }
        public void Run()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("HR_CRUD_Menu:");
                Console.WriteLine("1 - StudentCreate");
                Console.WriteLine("2 - AddressCreate");
                Console.WriteLine("3 - Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        //Console.WriteLine("StudentCreate");
                        hr_UI.StudentCreate();
                        break;
                    case 2:
                        //Console.WriteLine("AddressCreate");
                        hr_UI.AddressCreate();
                        break;
                    case 3:
                        Console.WriteLine("Exit");
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("Wrong choice!");
                        break;
                }
            }
        }

    }
}
