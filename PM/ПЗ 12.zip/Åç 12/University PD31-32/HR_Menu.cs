﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    class HR_Menu
    {
        HR_CRUD_Menu hR_CRUD_Menu;
        HR_Services_Menu hR_Services_Menu;
        public HR_Menu(HR_CRUD_Menu hR_CRUD_Menu, HR_Services_Menu hR_Services_Menu)
        {
            this.hR_CRUD_Menu = hR_CRUD_Menu;
            this.hR_Services_Menu = hR_Services_Menu;
        }
        public void Run()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("HR_Menu:");
                Console.WriteLine("1 - HR_CRUD_Menu");
                Console.WriteLine("2 - HR_Services_Menu");
                Console.WriteLine("3 - Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        //Console.WriteLine("HR_CRUD_Menu");
                        hR_CRUD_Menu.Run();
                        break;
                    case 2:
                        //Console.WriteLine("HR_Services_Menu");
                        hR_Services_Menu.Run();
                        break;
                    case 3:
                        Console.WriteLine("Exit");
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("Wrong choice!");
                        break;
                }
            }
        }

    }
}
