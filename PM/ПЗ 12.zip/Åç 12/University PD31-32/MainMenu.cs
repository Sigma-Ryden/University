﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University_PD31_32
{
    class MainMenu
    {
        HR_Menu hR_Menu;
        public MainMenu(HR_Menu hR_Menu)
        {
            this.hR_Menu = hR_Menu;
        }
        public void Run()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("MainMenu:");
                Console.WriteLine("1 - HR_Menu");
                Console.WriteLine("2 - DepartmentMenu");
                Console.WriteLine("3 - Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        //Console.WriteLine("HR_Menu");
                        hR_Menu.Run();
                        break;
                    case 2:
                        Console.WriteLine("DepartmentMenu");
                        break;
                    case 3:
                        Console.WriteLine("Exit");
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("Wrong choice!");
                        break;
                }
            }
        }
    }
}
