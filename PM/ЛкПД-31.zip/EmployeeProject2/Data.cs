﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeProject
{
    class Data
    {
        public Employee employee { get; set; }
    }
}
