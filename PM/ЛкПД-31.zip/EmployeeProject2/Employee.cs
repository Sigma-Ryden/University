﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeProject
{
    class Employee
    {
        private int count = 1;
        public int Id { get; set; }
        public string Name { get; set; }
        public Employee(string name)
        {
            Id = count++;
            Name = name;
        }
        public override string ToString()
        {
            return String.Format(Id + " " + Name);
        }
    }
}
