﻿using System;

namespace EmployeeProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Data data = new Data();

            ICommand createEmployee = new CreateEmployee(data);
            HR hrCreateEmployee = new HR(createEmployee);
            hrCreateEmployee.Run();

            ICommand employeeShow = new EmployeeShow(data);
            HR hrEmployeeShow = new HR(employeeShow);
            hrEmployeeShow.Run();
            

            Console.ReadLine();
        }
    }
}
