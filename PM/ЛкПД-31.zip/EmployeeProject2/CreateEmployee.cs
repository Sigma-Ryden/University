﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeProject
{
    class CreateEmployee : ICommand
    {
        Data data;
        public CreateEmployee(Data data)
        {
            this.data = data;
        }
        public void Run()
        {
            EmployeeCreate();
        }
        private void EmployeeCreate()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Employee employee = new Employee(name);
            data.employee = employee;
        }
    }
}
