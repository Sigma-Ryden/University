﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeProject
{
    interface ICommand
    {
        void Run();
    }
}
