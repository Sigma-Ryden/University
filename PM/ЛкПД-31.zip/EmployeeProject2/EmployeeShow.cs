﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeProject
{
    class EmployeeShow : ICommand
    {
        Data data;
        public EmployeeShow(Data data)
        {
            this.data = data;
        }
        public void Run()
        {
            ShowEmployee();
        }
        private void ShowEmployee()
        {
            Console.WriteLine(data.employee);
        }
    }
}
