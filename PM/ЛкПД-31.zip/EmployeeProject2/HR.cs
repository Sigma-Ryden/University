﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeProject
{
    class HR
    {
        ICommand commandObject;
        //Employee employee;
        public HR(ICommand commandObject)
        {
            this.commandObject = commandObject;
        }
        /*
        public void EmployeeCreate()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();
            employee = new Employee(name);
        }
        public void ShowEmployee()
        {
            Console.WriteLine(employee);
        }
        */
        public void Run()
        {
            commandObject.Run();
        }
    }
}
