#ifndef TRIXY_SERIALIZER_BASE_HPP
#define TRIXY_SERIALIZER_BASE_HPP

namespace trixy
{

template <class Serializable, typename enable = void>
class Serializer;

} // namespace trixy

#endif // TRIXY_SERIALIZER_BASE_HPP
