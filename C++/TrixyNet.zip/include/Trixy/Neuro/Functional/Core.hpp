#ifndef TRIXY_FUNCTIONAL_CORE_HPP
#define TRIXY_FUNCTIONAL_CORE_HPP

#include <Trixy/Neuro/Functional/Base.hpp>

#include <Trixy/Neuro/Functional/Id.hpp>

#include <Trixy/Neuro/Functional/FeedForwardNet.hpp>

#endif // TRIXY_FUNCTIONAL_CORE_HPP
