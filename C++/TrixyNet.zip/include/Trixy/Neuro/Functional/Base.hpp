#ifndef TRIXY_FUNCTIONAL_BASE_HPP
#define TRIXY_FUNCTIONAL_BASE_HPP

namespace trixy
{

template <class Functionable, typename enable = void>
class Functional;

} // namespace trixy

#endif // TRIXY_FUNCTIONAL_BASE_HPP
