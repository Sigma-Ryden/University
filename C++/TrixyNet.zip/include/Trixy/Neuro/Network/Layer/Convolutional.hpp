#ifndef TRIXY_NETWORK_LAYER_CONVOLUTIONAL_HPP
#define TRIXY_NETWORK_LAYER_CONVOLUTIONAL_HPP

#include <Trixy/Neuro/Network/Layer/Base.hpp>

#include <Trixy/Detail/TrixyMeta.hpp>

#include <Trixy/Neuro/Network/Layer/Detail/MacroScope.hpp>

namespace trixy
{

namespace layer
{

// Comming soon...

} // namespace layer

} // namespace trixy

#include <Trixy/Neuro/Network/Layer/Detail/MacroUnscope.hpp>

#endif // TRIXY_NETWORK_LAYER_CONVOLUTIONAL_HPP
