#ifndef TRIXY_CONTAINER_CORE_HPP
#define TRIXY_CONTAINER_CORE_HPP

#include <Trixy/Container/Container.hpp>
#include <Trixy/Container/IContainer.hpp>

#endif // TRIXY_CONTAINER_CORE_HPP
