#ifndef TRIXY_RANGE_CORE_HPP
#define TRIXY_RANGE_CORE_HPP

#include <Trixy/Range/Base.hpp>

#include <Trixy/Range/View.hpp>
#include <Trixy/Range/Unified.hpp>

#endif // TRIXY_RANGE_CORE_HPP

