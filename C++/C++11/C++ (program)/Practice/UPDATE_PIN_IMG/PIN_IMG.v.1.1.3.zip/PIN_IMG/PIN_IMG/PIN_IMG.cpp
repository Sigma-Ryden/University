﻿//
//	HACK Graphic key 
//
#include "pch.h"
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int first, gr_key, incoh = 0, replay = 0;
	do
	{
		cout << "Enter Graphic key: ";
		cin >> gr_key;
		if (gr_key > pow(10, 9) - 1 || gr_key < pow(10, 3))
		{
			cout << "Enter a number between 4 and 9 digits!\n";
		}
	} while (gr_key > pow(10, 9) - 1 || gr_key < pow(10, 3));

	first = gr_key % 10;
	gr_key /= 10;

//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
//
//  Выбор возможности отладки (для разработчиков)
//
//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

	cout << "\nEnable debug mode? Chose answer: Y \\ N: ";

	char line;
	bool use_Ptwo = 0, use_Pfour = 0, use_Psix = 0, use_Peight = 0, use_Pfive = 0, flag_options = 1;

	do
	{
		cin >> line;
		if (line == 'Y')
		{
			cout << "Debug mode allows you to see the number of errors and changes!\n";
			break;
		}
		else if (line == 'N')
			{
			cout << "You can only see the key opportunity!\n";
			flag_options = false;
			break;
			}
		else cout << "Please choose only answer Y or N: ";
	} while (line != 'Y' || line != 'N');
	cout << "\nGraphic key layout: ";
	cout << first << " ";

	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0, seven = 0, eight = 0, nine = 0;

	for (int GG, Re; gr_key > 0; gr_key /= 10)
	{

//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
//
//  Проверка на возможность комбинации
//  For example: 4587369 -> enter 9637854 or 426139 -> 931624, когда
//  5 - я точка	поднята, условие на сумму угловых точек равняется false
//
//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

		GG = gr_key % 10;
		Re = first + GG;

		if (first == GG || GG == 0)
		{
			incoh++;
		}
		switch (first)
		{
			case 1:
			{
				if (Re == 4 || Re == 8 || Re == 10)
				{
					if (use_Pfive == true && Re == 10 ) first = GG;
					else if (use_Pfive == false && Re == 10)
					{
						incoh++;
						first = GG;
					}
					if (use_Ptwo == true && Re == 4) first = GG;
					else if (use_Ptwo == false && Re == 4)
					{
						incoh++;
						first = GG;
					}
					if (use_Pfour == true && Re == 8) first = GG;
					else if (use_Pfour == false && Re == 8)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				one++;
				break;
			}
			case 3:
			{
				if (Re == 4 || Re == 10 || Re == 12)
				{
					if (use_Pfive == true && Re == 10) first = GG;
					else if (use_Pfive == false && Re == 10)
					{
						incoh++;
						first = GG;
					}
					if (use_Ptwo == true && Re == 4) first = GG;
					else if (use_Ptwo == false && Re == 4)
					{
						incoh++;
						first = GG;
					}
					if (use_Psix == true && Re == 12) first = GG;
					else if (use_Psix == false && Re == 12)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				three++;
				break;
			}
			case 5:
			{
				first = GG;
				use_Pfive = true;
				five++;
				break;
			}
			case 7:
			{
				if (Re == 8 || Re == 10 || Re == 16)
				{
					if (use_Pfive == true && Re == 10) first = GG;
					else if (use_Pfive == false && Re == 10)
					{
						incoh++;
						first = GG;
					}
					if (use_Pfour == true && Re == 8) first = GG;
					else if (use_Pfour == false && Re == 8)
					{
						incoh++;
						first = GG;
					}
					if (use_Peight == true && Re == 16) first = GG;
					else if (use_Peight == false && Re == 16)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				seven++;
				break;
			}
			case 9:
			{
				if (Re == 10 || Re == 12 || Re == 16)
				{
					if (use_Pfive == true && Re == 10) first = GG;
					else if (use_Pfive == false && Re == 10)
					{
						incoh++;
						first = GG;
					}
					if (use_Psix == true && Re == 12) first = GG;
					else if (use_Psix == false && Re == 12)
					{
						incoh++;
						first = GG;
					}
					if (use_Peight == true && Re == 16) first = GG;
					else if (use_Peight == false && Re == 16)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				nine++;
				break;
			}
			case 2:
			{
				if (Re == 10)
				{
					if (use_Pfive == true) first = GG;
					else if (use_Pfive == false)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				use_Ptwo = true;
				two++;
				break;
			}
			case 4:
			{
				if (Re == 10)
				{
					if (use_Pfive == true) first = GG;
					else if (use_Pfive == false)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				use_Pfour = true;
				four++;
				break;
			}
			case 6:
			{
				if (Re == 10)
				{
					if (use_Pfive == true) first = GG;
					else if (use_Pfive == false)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				use_Psix = true;
				six++;
				break;
			}
			case 8:
			{
				if (Re == 10)
				{
					if (use_Pfive == true) first = GG;
					else if (use_Pfive == false)
					{
						incoh++;
						first = GG;
					}
				}
				else first = GG;
				use_Peight = true;
				eight++;
				break;
			}
			default:
			{
				incoh++;
				first = GG;
				break;
			}
		}
		cout << first << " ";
		if (one > 1 || two > 1 || three > 1 || four > 1 || five > 1) replay++;
		if (six > 1 || seven > 1 || eight > 1 || nine > 1) replay++;
	}
	if (flag_options == true)
	{
		cout << "\nIncoherent chains: " << incoh;
		cout<< "\nNumber of uses of the center point: " << use_Pfive;
		cout << "\nReplay numbers: " << replay;
	}
	bool start_hack = false;

//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
//
//  Проверка ключа окончена, если она
//	существует, то предложить что с ним делать
//
//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

	if (incoh == 0 && replay == 0)
	{
		cout << "\n\nKey exists!\nHACK this key ? (ans: Y \\ N) : ";
		do
		{
			cin >> line;
			if (line == 'Y')
			{
				cout << "\nWell, let's get started!\n";
				start_hack = true;
				break;
			}
			else if (line == 'N')
			{
				cout << "\nGet on your knees and pray!\n";
				break;
			}
			else cout << "Please choose only answer Y or N: ";

		} while (line != 'Y' || line != 'N');
	}
	else
	{
		cout << "\n\nKey does not exist!";
	}
	if (start_hack == true)
	{
		enum fn_matrix { a11 = 1, a12, a13, a21, a22, a23, a31, a32, a33 };
	}

	cout << "\n";
	system("pause");
	return 0;
}