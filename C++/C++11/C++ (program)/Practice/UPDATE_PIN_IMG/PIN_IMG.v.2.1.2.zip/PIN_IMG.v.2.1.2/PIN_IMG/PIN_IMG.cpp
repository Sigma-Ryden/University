																	//
/*HACK Graphic key*/												//  Изучить 73стр.-81стр. (ИСПРАВЛЕНО)
																	/// backwards - will be fixed soon (Исправленно)
#include "pch.h"
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int first, first_test, gr_key, incoh = 0, grow=0;
	do
	{
		grow=0;
		cout << "Enter Graphic key: ";
		cin >> gr_key;
		if (gr_key > pow(10, 9) - 1 || gr_key < pow(10, 3))
		{
			cout << "Enter a number between 4 and 9 digits!\n";
		}
		for (int gr_key_test = gr_key; gr_key_test > 0; gr_key_test /= 10, grow++)
		{
			first_test = gr_key_test % 10;
			if (first_test == 0)
			{
				cout << "Incorrect key, try again!\n";
				break;
			}
		}
	} while ((gr_key > pow(10, 9) - 1 || gr_key < pow(10, 3)) || first_test==0);
	//
	int long_gr_key[9]{0};
	cout<<"Back_numb [ ";
	for (int gr_key_back=gr_key, Rq=9; Rq>0; gr_key_back/=10)
	{
		Rq--;
		long_gr_key[Rq]=gr_key_back%10;
		if (long_gr_key[Rq]==0)
		{
			continue;
		}
		cout<<long_gr_key[Rq];
	}
	cout<<" ]";
	
	first = long_gr_key[0];											//
														///  Выбор возможности отладки (для разработчиков)
																	//  
	cout << "\nEnable debug mode? Chose answer: Y \\ N: ";

	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0, seven = 0, eight = 0, nine = 0;
	char line;
	bool use_Ptwo = 0, use_Pfour = 0, use_Psix = 0, use_Peight = 0, use_Pfive = 0, flag_options = 1;

	do {
		cin >> line;
		if (line == 'Y')
		{
			cout << "Debug mode allows you to see the number of errors and changes!\n";
			break;
		}
		else if (line == 'N')
		{
			cout << "You can only see the key opportunity!\n";
			flag_options = false;
			break;
		}
		else cout << "Please choose only answer Y or N: ";
	} while (line != 'Y' || line != 'N');
	cout << "\nGraphic key layout: ";
	cout << first << " ";

	const int ROWS = 3, COLS = 3;
	int st_matrix[ROWS][COLS]{}, step = 0;
	long_gr_key[step]=first;
																	//
	for (int i = 0; i < ROWS; i++)									//  Проверка на возможность комбинации.
	{
		for (int j = 0, Re, GG; j < COLS; /*gr_key /= 10,*/ j++)
		{
			st_matrix[i][j] = long_gr_key[step];
			step++;
			GG = long_gr_key[step];
			Re = first + GG;										//  For example: 4587369 -> enter 9637854
																	//  or 426139 -> 931624, когда
											//  5 - я точка	поднята, условие на
																	//  сумму угловых точек равняется false.
			switch (first)											/// 188 строк кода - скоро будет оптимизированно.
			{
				case 1:
				{
					if (Re == 4 || Re == 8 || Re == 10)
					{
						if (use_Pfive == true && Re == 10) first = GG;
						else if (use_Pfive == false && Re == 10)
						{
							incoh++;
							first = GG;
						}
						if (use_Ptwo == true && Re == 4) first = GG;
						else if (use_Ptwo == false && Re == 4)
						{
							incoh++;
							first = GG;
						}
						if (use_Pfour == true && Re == 8) first = GG;
						else if (use_Pfour == false && Re == 8)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					one++;
					break;
				}
				case 3:
				{
					if (Re == 4 || Re == 10 || Re == 12)
					{
						if (use_Pfive == true && Re == 10) first = GG;
						else if (use_Pfive == false && Re == 10)
						{
							incoh++;
							first = GG;
						}
						if (use_Ptwo == true && Re == 4) first = GG;
						else if (use_Ptwo == false && Re == 4)
						{
							incoh++;
							first = GG;
						}
						if (use_Psix == true && Re == 12) first = GG;
						else if (use_Psix == false && Re == 12)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					three++;
					break;
				}
				case 5:
				{
					first = GG;
					use_Pfive = true;
					five++;
					break;
				}
				case 7:
				{
					if (Re == 8 || Re == 10 || Re == 16)
					{
						if (use_Pfive == true && Re == 10) first = GG;
						else if (use_Pfive == false && Re == 10)
						{
							incoh++;
							first = GG;
						}
						if (use_Pfour == true && Re == 8) first = GG;
						else if (use_Pfour == false && Re == 8)
						{
							incoh++;
							first = GG;
						}
						if (use_Peight == true && Re == 16) first = GG;
						else if (use_Peight == false && Re == 16)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					seven++;
					break;
				}
				case 9:
				{
					if (Re == 10 || Re == 12 || Re == 16)
					{
						if (use_Pfive == true && Re == 10) first = GG;
						else if (use_Pfive == false && Re == 10)
						{
							incoh++;
							first = GG;
						}
						if (use_Psix == true && Re == 12) first = GG;
						else if (use_Psix == false && Re == 12)
						{
							incoh++;
							first = GG;
						}
						if (use_Peight == true && Re == 16) first = GG;
						else if (use_Peight == false && Re == 16)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					nine++;
					break;
				}
				case 2:
				{
					if (Re == 10)
					{
						if (use_Pfive == true) first = GG;
						else if (use_Pfive == false)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					use_Ptwo = true;
					two++;
					break;
				}
				case 4:
				{
					if (Re == 10)
					{
						if (use_Pfive == true) first = GG;
						else if (use_Pfive == false)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					use_Pfour = true;
					four++;
					break;
				}
				case 6:
				{
					if (Re == 10)
					{
						if (use_Pfive == true) first = GG;
						else if (use_Pfive == false)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					use_Psix = true;
					six++;
					break;
				}
				case 8:
				{
					if (Re == 10)
					{
						if (use_Pfive == true) first = GG;
						else if (use_Pfive == false)
						{
							incoh++;
							first = GG;
						}
					}
					else first = GG;
					use_Peight = true;
					eight++;
					break;
				}
				default : 
				{
					first = GG;
					break;
				}
			}
			if (step <9) cout << first << " ";
		}
	}
	if (flag_options == true)
	{
		cout << "\n\nMasKey [3][3] = { { ";							 //  Цепочка вводиться с начала, а не с конца,
		for (int i = 0; i < ROWS; i++)								 //  как это было задумано. Например:
		{															 //  число 92, программа ввыводит его
			for (int j = 0; j < COLS; j++)							 //  так: mas [2][2] = {(9,2},{0,0}} (некий массив 2*2),
			{
				j == 2 ? cout << st_matrix[i][j] : cout << st_matrix[i][j] << ", ";
				if (COLS - j == 1) cout << " }";
			}														 //  а красивее дожно было быть так:
			if (ROWS - i != 1) cout << ", { ";						 //  mas[2][2] = {{0,0},{9,2}} - верная запись.
		}															 /// скоро будет исправлено...
		cout << " }\n";
		cout << "\nKey length: <" << grow << "> points";
		cout << "\nIncoherent chains: " << incoh;
		cout << "\nNumber of uses of the center point: " << use_Pfive;
		if (one > 1 || two > 1 || three > 1 || four > 1 || five > 1 || six > 1 || seven > 1 || eight > 1 || nine > 1)
		{
			cout << "\n\nReplay number - [1] : " << one;
			cout << "\t\tReplay number - [6] : " << six;
			cout << "\nReplay number - [2] : " << two;
			cout << "\t\tReplay number - [7] : " << seven;
			cout << "\nReplay number - [3] : " << three;
			cout << "\t\tReplay number - [8] : " << eight;
			cout << "\nReplay number - [4] : " << four;
			cout << "\t\tReplay number - [9] : " << nine;
			cout << "\nReplay number - [5] : " << five;
			cout << "\t\tReplay number - [0] : -";
		}
		else cout << "\n\nReplay numbers : 0";
	}
	bool start_hack = false;
	
	if (incoh == 0 && !(one > 1 || two > 1 || three > 1 || four > 1 || five > 1 || six > 1 || seven > 1 || eight > 1 || nine > 1))
	{																	
		cout << "\n\nKey exists!\n\nHACK this key ? (ans: Y \\ N) : ";	
		do{
			cin >> line;
			if (line == 'Y')
			{														//
				cout << "\nWell, let's get started!\n";				//  Проверка ключа окончена, если он
				start_hack = true;									//	существует, то выбрать, что с ним делать.
				break;												//
			}
			else if (line == 'N')
			{
				cout << "\nGet on your knees and pray!\n";
				break;
			}
			else cout << "Please choose only answer Y or N: ";

		} while (line != 'Y' || line != 'N');
	}
	else
	{
		cout << "\n\nKey does not exist!";
	}
	if (start_hack == true)
	{
		const int R = 3, L = 3;
		int matrix_hack[R][L] { };
	}
	cout << "\n";
	system("pause");
	return 0;
}