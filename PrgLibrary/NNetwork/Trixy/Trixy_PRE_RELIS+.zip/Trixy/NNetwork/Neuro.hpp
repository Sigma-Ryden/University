#ifndef NEURO_HPP
#define NEURO_HPP

#include <initializer_list>
#include <cstddef>
#include <cmath>
#include <iostream>

#include "Liangle/li_utils.hpp"

namespace li = liangle;

template <class Matrix, class Vector, template <typename...> class Dictionary>
class Neuro
{
private:
    Dictionary<Matrix> W;
    Dictionary<Vector> B;

    std::size_t N;

    double (*F)(double);
    double (*DF)(double);

public:
    Neuro(const std::initializer_list<std::size_t>& inner);
    Neuro(const Dictionary<Matrix>& weight, const Dictionary<Vector>& bias);

    Neuro(const Neuro&) = default;
    Neuro(Neuro&&) = default;
    Neuro& operator= (const Neuro&) = default;
    Neuro& operator= (Neuro&&) = default;

    void initializeInnerStruct(double (*generator)());
    void setActivationFunction(double (*function)(double), double (*function_derived)(double));

    const Dictionary<Matrix>& getInnerWeight() const;
    const Dictionary<Vector>& getInnerBias() const;

    Vector feedforward(const Vector&) const;
    Matrix feedforward(const Matrix&) const;

    void trainStochastic(
        const Matrix& in, const Matrix& out, double learn_rate, std::size_t epoch_rate);
    void trainBatch(
        const Matrix& in, const Matrix& out, double learn_rate, std::size_t epoch_rate);
    void trainMiniBatch(
        const Matrix& in, const Matrix& out, double learn_rate,
        std::size_t epoch_rate, std::size_t batch_split); //experimental

    double accuracy(const Matrix& in, const Matrix& out) const; //repair
    double accuracy(const Matrix& in, const Matrix& out, double range_rate) const; //repair
    double loss(const Matrix& in, const Matrix& out) const; //repair

private:
    static double mean(const Matrix&, const Matrix&);
};

template <class Matrix, class Vector, template <typename...> class Dictionary>
Neuro<Matrix, Vector, Dictionary>::Neuro(const std::initializer_list<std::size_t>& inner)
    : W(inner.size() - 1), B(inner.size() - 1), N(inner.size() - 1)
{
    auto layer = inner.begin() + 1;
    for(std::size_t i = 0; i < N; ++i)
    {
        W[i] = Matrix(*(layer - 1), *layer);
        B[i] = Vector(*layer);
        ++layer;
    }
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
Neuro<Matrix, Vector, Dictionary>::Neuro(
    const Dictionary<Matrix>& inner_W, const Dictionary<Vector>& inner_B)
    : W(inner_W), B(inner_B), N(inner_B.size())
{
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
void Neuro<Matrix, Vector, Dictionary>::initializeInnerStruct(double (*generator)())
{
    for(std::size_t i = 0; i < N; ++i)
    {
        li::fill_matrix(W[i], generator);
        li::fill_vector(B[i], generator);
    }
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
void Neuro<Matrix, Vector, Dictionary>::setActivationFunction(
    double (*function)(double), double (*function_derived)(double))
{
    F = function;
    DF = function_derived;
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
const Dictionary<Matrix>& Neuro<Matrix, Vector, Dictionary>::getInnerWeight() const
{
    return W;
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
const Dictionary<Vector>& Neuro<Matrix, Vector, Dictionary>::getInnerBias() const
{
    return B;
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
Vector Neuro<Matrix, Vector, Dictionary>::feedforward(const Vector& vector) const
{
    Vector y_pred = vector;
    for(std::size_t i = 0; i < N; ++i)
        y_pred = li::apply_to_vector(li::dot(y_pred, W[i]) + B[i], F);

    return y_pred;
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
Matrix Neuro<Matrix, Vector, Dictionary>::feedforward(const Matrix & in) const
{
    const std::size_t batch_size = in.row();
    const std::size_t output_size = W[N - 1].col();

    Matrix y_pred(batch_size, output_size);
    Vector out;

    for(std::size_t i = 0; i < batch_size; ++i)
    {
        out = feedforward(li::get<Vector>(in, i));
        for(std::size_t j = 0; j < out.size(); ++j)
            y_pred(i, j) = out(j);
    }

    return y_pred;
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
void Neuro<Matrix, Vector, Dictionary>::trainStochastic(
    const Matrix& in, const Matrix& out, double learn_rate, std::size_t epoch_rate)
{
    Dictionary<Vector> H(N + 1);
    Dictionary<Vector> S(N);
    Dictionary<Vector> DH(N);
    Dictionary<Matrix> DW(N);
    Dictionary<Vector> DB(N);

    Matrix pred_out(out.row(), out.col());
    Vector theta;

    std::size_t within = in.row();
    std::size_t sample;

    for(std::size_t epoch = 0; epoch < epoch_rate; ++epoch)
    {
        sample = rand() % within;

        H[0] = li::get<Vector>(in, sample);
        for(std::size_t i = 0; i < N; ++i)
        {
            S[i]        = li::dot(H[i], W[i]) + B[i];
            H[i + 1]    = li::apply_to_vector(S[i], F);
            DH[i]       = li::apply_to_vector(S[i], DF);
        }

        theta = H[N] - li::get<Vector>(out, sample);
        for(std::size_t i = N - 1; i > 0; --i)
        {
            DW[i] = li::join(li::tensordot<Matrix>(DH[i], H[i]), theta);
            DB[i] = DH[i].join(theta);

            theta = li::dot_T(theta, li::join(W[i], DH[i]));
        }
        DW[0] = li::join(li::tensordot<Matrix>(DH[0], H[0]), theta);
        DB[0] = DH[0].join(theta);

        for(std::size_t i = 0; i < N; ++i)
        {
            W[i] -= learn_rate * DW[i];
            B[i] -= learn_rate * DB[i];
        }
        //
        if((epoch + 1)% 100 == 0)
        {
            //std::cout << "Epoch " << epoch + 1 << " loss: " << loss(in, out) << '\n';
            std::cout << "Epoch " << epoch + 1 << '\n';
        }
        //
    }
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
void Neuro<Matrix, Vector, Dictionary>::trainBatch(
    const Matrix &in, const Matrix &out, double learn_rate, std::size_t epoch_rate)
{
    Dictionary<Vector> H(N + 1);
    Dictionary<Vector> S(N);
    Dictionary<Vector> DH(N);
    Dictionary<Matrix> DW(N);
    Dictionary<Vector> DB(N);

    Matrix pred_out(out.row(), out.col());
    Vector theta;

    Dictionary<Matrix> deltaW(N);
    Dictionary<Vector> deltaB(N);

    for(std::size_t i = 0; i < N; ++i)
    {
        deltaW[i].resize(W[i].row(), W[i].col());
        deltaB[i].resize(B[i].size());
    }

    learn_rate /= in.row();

    for(std::size_t epoch = 0; epoch < epoch_rate; ++epoch)
    {
        for(std::size_t i = 0; i < N; ++i)
        {
            li::fill_matrix(deltaW[i], [] { return 0.0; });
            li::fill_vector(deltaB[i], [] { return 0.0; });
        }

        for(std::size_t sample = 0; sample < in.row(); ++sample)
        {
            H[0] = li::get<Vector>(in, sample);
            for(std::size_t i = 0; i < N; ++i)
            {
                S[i]     = li::dot(H[i], W[i]) + B[i];
                H[i + 1] = li::apply_to_vector(S[i], F);
                DH[i]    = li::apply_to_vector(S[i], DF);
            }

            theta = H[N] - li::get<Vector>(out, sample);
            for(std::size_t i = N - 1; i > 0; --i)
            {
                DW[i] = li::join(li::tensordot<Matrix>(DH[i], H[i]), theta);
                DB[i] = DH[i].join(theta);

                theta = li::dot_T(theta, li::join(W[i], DH[i]));
            }
            DW[0] = li::join(li::tensordot<Matrix>(DH[0], H[0]), theta);
            DB[0] = DH[0].join(theta);

            for(std::size_t i = 0; i < N; ++i)
            {
                deltaW[i] += DW[i];
                deltaB[i] += DB[i];
            }
        }

        for(std::size_t i = 0; i < N; ++i)
        {
            W[i] -= learn_rate * deltaW[i];
            B[i] -= learn_rate * deltaB[i];
        }
        //
        if((epoch + 1)% 100 == 0)
        {
            //std::cout << "Epoch " << epoch + 1 << " loss: " << loss(in, out) << '\n';
            std::cout << "Epoch " << epoch + 1 << '\n';
        }
        //
    }
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
void Neuro<Matrix, Vector, Dictionary>::trainMiniBatch(
    const Matrix &in, const Matrix &out, double learn_rate,
    std::size_t epoch_rate, std::size_t batch_split)
{
    Dictionary<Vector> H(N + 1);
    Dictionary<Vector> S(N);
    Dictionary<Vector> DH(N);
    Dictionary<Matrix> DW(N);
    Dictionary<Vector> DB(N);

    Matrix pred_out(out.row(), out.col());
    Vector theta;

    Dictionary<Matrix> deltaW(N);
    Dictionary<Vector> deltaB(N);

    for(std::size_t i = 0; i < N; ++i)
    {
        deltaW[i].resize(W[i].row(), W[i].col());
        deltaB[i].resize(B[i].size());
    }

    std::size_t mini_batch_size = in.row() / batch_split;
    std::size_t sample_begin = 0;
    std::size_t sample_end   = 0;

    learn_rate /= mini_batch_size;

    for(std::size_t epoch = 0; epoch < epoch_rate; ++epoch)
    {
        sample_end += mini_batch_size;

        for(std::size_t i = 0; i < N; ++i)
        {
            li::fill_matrix(deltaW[i], [] { return 0.0; });
            li::fill_vector(deltaB[i], [] { return 0.0; });
        }

        while(sample_begin < sample_end)
        {
            H[0] = li::get<Vector>(in, sample_begin);
            for(std::size_t i = 0; i < N; ++i)
            {
                S[i]     = li::dot(H[i], W[i]) + B[i];
                H[i + 1] = li::apply_to_vector(S[i], F);
                DH[i]    = li::apply_to_vector(S[i], DF);
            }

            theta = H[N] - li::get<Vector>(out, sample_begin);
            for(std::size_t i = N - 1; i > 0; --i)
            {
                DW[i] = li::join(li::tensordot<Matrix>(DH[i], H[i]), theta);
                DB[i] = DH[i].join(theta);

                theta = li::dot_T(theta, li::join(W[i], DH[i]));
            }
            DW[0] = li::join(li::tensordot<Matrix>(DH[0], H[0]), theta);
            DB[0] = DH[0].join(theta);

            for(std::size_t i = 0; i < N; ++i)
            {
                deltaW[i] += DW[i];
                deltaB[i] += DB[i];
            }

            ++sample_begin;
        }

        for(std::size_t i = 0; i < N; ++i)
        {
            W[i] -= learn_rate * deltaW[i];
            B[i] -= learn_rate * deltaB[i];
        }

        sample_begin %= in.row();
        sample_end   %= in.row();

        //
        if((epoch + 1)% 100 == 0)
        {
            //std::cout << "Epoch " << epoch + 1 << " loss: " << loss(in, out) << '\n';
            std::cout << "Epoch " << epoch + 1 << '\n';
        }
        //
    }
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
double Neuro<Matrix, Vector, Dictionary>::accuracy(
    const Matrix& in, const Matrix& out) const
{
    Matrix pred_out = feedforward(in);
    double count = 0.0;

    std::size_t max_pred_out;
    std::size_t max_out;

    for(std::size_t i = 0; i < pred_out.row(); ++i)
    {
        max_pred_out = 0;
        max_out = 0;

        for(std::size_t j = 0; j < pred_out.col(); ++j)
            if(pred_out(i, max_pred_out)  < pred_out(i, j))
                max_pred_out = j;

        for(std::size_t j = 0; j < out.col(); ++j)
            if(out(i, max_out)  < out(i, j))
                max_out = j;

        if(max_pred_out == max_out)
            ++count;
    }

    return count / in.row();
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
double Neuro<Matrix, Vector, Dictionary>::accuracy(
    const Matrix& in, const Matrix& out, double range_rate) const
{
    Matrix pred_out = feedforward(in);
    double count = 0;
    bool answer;

    for(std::size_t i = 0; i < out.row(); ++i)
    {
        answer = true;
        for(std::size_t j = 0; j < out.col(); ++j)
        {
            if(std::fabs(pred_out(i, j) - out(i, j)) > range_rate)
            {
                answer = false;
                break;
            }
        }
        if(answer)
        {
            ++count;
        }
    }
    return count / in.row();
}

template <class Matrix, class Vector, template <typename...> class Dictionary>
double Neuro<Matrix, Vector, Dictionary>::loss(const Matrix& in, const Matrix& out) const
{
    Matrix pred = feedforward(in);
    double result = 0.0;

    for (std::size_t i = 0; i < out.row(); ++i)
        for(std::size_t j = 0; j < out.col(); ++j)
            result += std::pow(out(i, j) - pred(i, j), 2);

    return result / out.row();
}

#endif // NEURO_HPP
