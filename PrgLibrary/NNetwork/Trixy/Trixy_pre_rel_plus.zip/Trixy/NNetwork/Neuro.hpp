#ifndef NEURO_HPP
#define NEURO_HPP

#include <initializer_list>
#include <iostream>
#include <cstddef>
#include <cmath>

#include "Liangle/li_utils.hpp"

namespace li = liangle;

template <template <typename...> class Dictionary, class Matrix, class Vector>
class Neuro
{
private:
    double (*F)(double);
    double (*DF)(double);

    Dictionary<Matrix> W;
    Dictionary<Vector> B;

    std::size_t N;

public:
    Neuro(const std::initializer_list<std::size_t>& inner);
    Neuro(const Dictionary<Matrix>& weight, const Dictionary<Vector>& bias);

    Neuro(const Neuro&) = default;
    Neuro(Neuro&&) = default;
    Neuro& operator= (const Neuro&) = default;
    Neuro& operator= (Neuro&&) = default;

    void initializeInnerStruct(double (*generator)());
    void setActivationFunction(double (*function)(double), double (*function_derived)(double));

    const Dictionary<Matrix>& getInnerWeight() const;
    const Dictionary<Vector>& getInnerBias() const;

    Vector feedforward(const Vector&) const;
    Matrix feedforward(const Matrix&) const;

    void trainStochastic(
        const Matrix& in, const Matrix& out, double learn_rate, std::size_t epoch_rate);
    void trainBatch(
        const Matrix& in, const Matrix& out, double learn_rate, std::size_t epoch_rate);

    double accuracy(const Matrix& in, const Matrix& out, double range_rate) const; //repair
    double loss(const Matrix& in, const Matrix& out) const; //repair

private:
    static double mean(const Matrix&, const Matrix&);
};

template <template <typename...> class Dictionary, class Matrix, class Vector>
Neuro<Dictionary, Matrix, Vector>::Neuro(const std::initializer_list<std::size_t>& inner)
    : W(inner.size() - 1), B(inner.size() - 1), N(inner.size() - 1)
{
    auto layer = inner.begin() + 1;
    for(std::size_t i = 0; i < N; ++i)
    {
        W[i] = Matrix(*(layer - 1), *layer);
        B[i] = Vector(*layer);
        ++layer;
    }
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
Neuro<Dictionary, Matrix, Vector>::Neuro(
    const Dictionary<Matrix>& inner_W, const Dictionary<Vector>& inner_B)
    : W(inner_W), B(inner_B), N(inner_B.size())
{
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
void Neuro<Dictionary, Matrix, Vector>::initializeInnerStruct(double (*generator)())
{
    for(std::size_t i = 0; i < N; ++i)
    {
        W[i].fill(generator);
        B[i].fill(generator);
    }
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
void Neuro<Dictionary, Matrix, Vector>::setActivationFunction(
    double (*function)(double), double (*function_derived)(double))
{
    F = function;
    DF = function_derived;
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
const Dictionary<Matrix>& Neuro<Dictionary, Matrix, Vector>::getInnerWeight() const
{
    return W;
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
const Dictionary<Vector>& Neuro<Dictionary, Matrix, Vector>::getInnerBias() const
{
    return B;
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
Vector Neuro<Dictionary, Matrix, Vector>::feedforward(const Vector& vector) const
{
    Vector y_pred = vector;
    for(std::size_t i = 0; i < N; ++i)
        y_pred = (li::dot(y_pred, W[i]) + B[i]).produce(F);

    return y_pred;
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
Matrix Neuro<Dictionary, Matrix, Vector>::feedforward(const Matrix & in) const
{
    const std::size_t batch_size = in.row();
    const std::size_t output_size = W[N - 1].col();

    Matrix y_pred(batch_size, output_size);
    Vector out;

    for(std::size_t i = 0; i < batch_size; ++i)
    {
        out = feedforward(li::get<Vector>(in, i));
        for(std::size_t j = 0; j < out.size(); ++j)
            y_pred(i, j) = out(j);
    }

    return y_pred;
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
void Neuro<Dictionary, Matrix, Vector>::trainStochastic(
    const Matrix& in, const Matrix& out, double learn_rate, std::size_t epoch_rate)
{
    Dictionary<Vector> H(N + 1);
    Dictionary<Vector> S(N);
    Dictionary<Vector> DH(N);
    Dictionary<Matrix> DW(N);
    Dictionary<Vector> DB(N);

    Matrix pred_out(out.row(), out.col());
    Vector theta;

    std::size_t within = in.row();
    std::size_t sample;

    for(std::size_t epoch = 0; epoch < epoch_rate; ++epoch)
    {
        sample = rand() % within;

        H[0] = li::get<Vector>(in, sample);
        for(std::size_t i = 0; i < N; ++i)
        {
            S[i]        = li::dot(H[i], W[i]) + B[i];
            H[i + 1]    = S[i].produce(F);
            DH[i]       = S[i].produce(DF);
        }

        theta = H[N] - li::get<Vector>(out, sample);
        for(std::size_t i = N - 1; i > 0; --i)
        {
            DW[i] = li::join(li::tensordot<Matrix>(DH[i], H[i]), theta);
            DB[i] = DH[i].join(theta);

            theta = li::dot_T(theta, li::join(W[i], DH[i]));
        }
        DW[0] = li::join(li::tensordot<Matrix>(DH[0], H[0]), theta);
        DB[0] = DH[0].join(theta);

        for(std::size_t i = 0; i < N; ++i)
        {
            W[i] -= learn_rate * DW[i];
            B[i] -= learn_rate * DB[i];
        }
        /*
        if((epoch + 1)% 100 == 0)
        {
            //std::cout << "Epoch " << epoch + 1<< " loss: " << loss(in, out) << '\n';
            std::cout << "Epoch " << epoch + 1<< '\n';
        }
        */
    }
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
void Neuro<Dictionary, Matrix, Vector>::trainBatch(
    const Matrix &in, const Matrix &out, double learn_rate, std::size_t epoch_rate)
{
    Dictionary<Vector> H(N + 1);
    Dictionary<Vector> S(N);
    Dictionary<Vector> DH(N);
    Dictionary<Matrix> DW(N);
    Dictionary<Vector> DB(N);

    Matrix pred_out(out.row(), out.col());
    Vector theta;

    Dictionary<Matrix> deltaW(N);
    Dictionary<Vector> deltaB(N);

    for(std::size_t i = 0; i < N; ++i)
    {
        deltaW[i].resize(W[i].row(), W[i].col());
        deltaB[i].resize(B[i].size());
    }

    learn_rate /= in.row();

    for(std::size_t epoch = 0; epoch < epoch_rate; ++epoch)
    {
        for(std::size_t i = 0; i < N; ++i)
        {
            deltaW[i].fill(0.0);
            deltaB[i].fill(0.0);
        }

        for(std::size_t sample = 0; sample < in.row(); ++sample)
        {
            H[0] = li::get<Vector>(in, sample);
            for(std::size_t i = 0; i < N; ++i)
            {
                S[i]        = li::dot(H[i], W[i]) + B[i];
                H[i + 1]    = S[i].produce(F);
                DH[i]       = S[i].produce(DF);
            }

            theta = H[N] - li::get<Vector>(out, sample);
            for(std::size_t i = N - 1; i > 0; --i)
            {
                DW[i] = li::join(li::tensordot<Matrix>(DH[i], H[i]), theta);
                DB[i] = DH[i].join(theta);

                theta = li::dot_T(theta, li::join(W[i], DH[i]));
            }
            DW[0] = li::join(li::tensordot<Matrix>(DH[0], H[0]), theta);
            DB[0] = DH[0].join(theta);

            for(std::size_t i = 0; i < N; ++i)
            {
                deltaW[i] += DW[i];
                deltaB[i] += DB[i];
            }
        }

        for(std::size_t i = 0; i < N; ++i)
        {
            W[i] -= learn_rate * deltaW[i];
            B[i] -= learn_rate * deltaB[i];
        }
        /*
        if((epoch + 1)% 100 == 0)
        {
            //std::cout << "Epoch " << epoch + 1<< " loss: " << loss(in, out) << '\n';
            std::cout << "Epoch " << epoch + 1 << '\n';
        }
        */
    }
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
double Neuro<Dictionary, Matrix, Vector>::accuracy(
    const Matrix& in, const Matrix& out, double range_rate) const
{
    Matrix pred_out = feedforward(in);
    double count = 0;
    bool check;

    for(std::size_t i = 0; i < out.row(); ++i)
    {
        check = true;
        for(std::size_t j = 0; j < out.col(); ++j)
        {
            if(std::fabs(pred_out(i, j) - out(i, j)) > range_rate)
            {
                check = false;
                break;
            }
        }
        if(check)
        {
            ++count;
        }
    }
    return count / in.row();
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
double Neuro<Dictionary, Matrix, Vector>::loss(const Matrix& in, const Matrix& out) const
{
    return mean(feedforward(in), out);
}

template <template <typename...> class Dictionary, class Matrix, class Vector>
double Neuro<Dictionary, Matrix, Vector>::mean(const Matrix& y_true, const Matrix& y_pred)
{
    double result = 0.0;

    for (std::size_t i = 0; i < y_true.row(); ++i)
        for(std::size_t j = 0; j < y_true.col(); ++j)
            result += std::pow(y_true(i, j) - y_pred(i, j), 2);

    return result / y_true.row();
}

#endif // NEURO_HPP
