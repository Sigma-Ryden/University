#ifndef LI_UTILS_H
#define LI_UTILS_H

#include <cstddef>

namespace liangle
{

template <template <typename...> class Matrix, template <typename...> class Vector, typename Type>
Vector<Type> dot(const Vector<Type>& vector, const Matrix<Type>& matrix)
{
    Vector<Type> new_vector(matrix.col());
    double result = 0.0;

    for(std::size_t i = 0; i < matrix.col(); ++i)
    {
        for(std::size_t j = 0; j <  matrix.row(); ++j)
            result += vector(j) * matrix(j, i);

        new_vector(i) = result;
        result = 0.0;
    }

    return new_vector;
}

template <template <typename...> class Matrix, template <typename...> class Vector, typename Type>
Vector<Type> dot_T(const Vector<Type>& vector, const Matrix<Type>& matrix)
{
    Vector<Type> new_vector(matrix.row());
    double result = 0.0;

    for(std::size_t i = 0; i < matrix.row(); ++i)
    {
        for(std::size_t j = 0; j <  matrix.col(); ++j)
            result += vector(j) * matrix(i, j);

        new_vector(i) = result;
        result = 0.0;
    }

    return new_vector;
}

template <template <typename...> class Matrix, template <typename...> class Vector, typename Type>
Matrix<Type> join(const Matrix<Type>& matrix, const Vector<Type>& vector)
{
    Matrix<Type> new_matrix(matrix.row(), matrix.col());

    for(std::size_t i = 0; i < matrix.row(); ++i)
        for(std::size_t j = 0; j < matrix.col(); ++j)
            new_matrix(i, j) = vector(j) * matrix(i, j);

    return new_matrix;
}

template <class Matrix, template <typename...> class Vector, typename Type>
Matrix tensordot(const Vector<Type>& a, const Vector<Type>& b)
{
    Matrix new_matrix(b.size(), a.size());

    for(std::size_t i = 0; i < b.size(); ++i)
        for(std::size_t j = 0; j < a.size(); ++j)
            new_matrix(i, j) = a(j) * b(i);

    return new_matrix;
}

template <class Vector, template <typename...> class Matrix, typename Type>
Vector get(const Matrix<Type>& matrix, std::size_t n_row)
{
    Vector new_vector(matrix.col());

    for(std::size_t i = 0; i < matrix.col(); ++i)
        new_vector(i) = matrix(n_row, i);

    return new_vector;
}

template <template <typename...> class Matrix, class Function, typename Type>
void fill_matrix(Matrix<Type>& matrix, Function generator)
{
    for(std::size_t i = 0; i < matrix.row(); ++i)
        for(std::size_t j = 0; j < matrix.col(); ++j)
            matrix(i, j) = generator();
}

template <template <typename...> class Matrix, typename Type>
void fill_matrix(Matrix<Type>& matrix, Type value)
{
    for(std::size_t i = 0; i < matrix.row(); ++i)
        for(std::size_t j = 0; j < matrix.col(); ++j)
            matrix(i, j) = value;
}

template <template <typename...> class Vector, class Function, typename Type>
void fill_vector(Vector<Type>& vector, Function generator)
{
    for(std::size_t i = 0; i < vector.size(); ++i)
        vector(i) = generator();
}

template <template <typename...> class Vector, typename Type>
void fill_vector(Vector<Type>& vector, Type value)
{
    for(std::size_t i = 0; i < vector.size(); ++i)
        vector(i) = value;
}

template <template <typename...> class Matrix, class Function, typename Type>
Matrix<Type> apply_to_matrix(Function function, const Matrix<Type>& matrix)
{
    Matrix<Type> new_matrix(matrix.row(), matrix.col());

    for(std::size_t i = 0; i < matrix.row(); ++i)
        for(std::size_t j = 0; j < matrix.col(); ++j)
            new_matrix(i, j) = function(matrix(i, j));

    return new_matrix;
}

template <class Function, template <typename...> class Vector, typename Type>
Vector<Type> apply_to_vector(Function function, const Vector<Type>& vector)
{
    Vector<Type> new_vector(vector.size());

    for(std::size_t i = 0; i < vector.size(); ++i)
        new_vector(i) = function(vector(i));

    return new_vector;
}

}
#endif // LI_UTILS_H
